http://apetools.webprofusion.com/ 

Icons and Splashscreens bundle generated 3/24/2017 7:45:38 PM.


iOS:
---------------------------------------
Icons:
	iOS\Resources\icons\Icon-small.png: W29 H29
	iOS\Resources\icons\Icon.png: W57 H57
	iOS\Resources\icons\Icon@2x.png: W114 H114
	iOS\Resources\icons\Icon-40.png: W40 H40
	iOS\Resources\icons\Icon-40@2x.png: W80 H80
	iOS\Resources\icons\Icon-small@3x.png: W87 H87
	iOS\Resources\icons\Icon-50.png: W50 H50
	iOS\Resources\icons\Icon-small@2x.png: W58 H58
	iOS\Resources\icons\Icon-50@2x.png: W100 H100
	iOS\Resources\icons\Icon-60.png: W60 H60
	iOS\Resources\icons\Icon-72.png: W72 H72
	iOS\Resources\icons\Icon-72@2x.png: W144 H144
	iOS\Resources\icons\Icon-76.png: W76 H76
	iOS\Resources\icons\Icon-40@2x.png: W80 H80
	iOS\Resources\icons\Icon-60@2x.png: W120 H120
	iOS\Resources\icons\Icon-76@2x.png: W152 H152
	iOS\Resources\icons\Icon-167.png: W167 H167
	iOS\Resources\icons\Icon-60@3x.png: W180 H180

Splashscreens:
	iOS\Resources\splash\Default~iphone.png: W320 H480
	iOS\Resources\splash\Default@2x~iphone_640x960.png: W640 H960
	iOS\Resources\splash\Default-568h@2x~iphone_640x1136.png: W640 H1136
	iOS\Resources\splash\Default-Landscape~ipad_1024x748.png: W1024 H748
	iOS\Resources\splash\Default-Landscape~ipad_1024x768.png: W1024 H768
	iOS\Resources\splash\Default-Landscape@2x~ipad_2048x1496.png: W2048 H1496
	iOS\Resources\splash\Default-Landscape@2x~ipad_2048x1536.png: W2048 H1536
	iOS\Resources\splash\Default~ipad.png: W1536 H2008
	iOS\Resources\splash\Default-Portrait@2x~ipad_1536x2048.png: W1536 H2048
	iOS\Resources\splash\Default-Portrait@2x~ipad_1536x2008.png: W1536 H2008
	iOS\Resources\splash\Default.png: W768 H1004
	iOS\Resources\splash\Default-Portrait~ipad_768x1024.png: W768 H1024
	iOS\Resources\splash\Default-750@2x~iphone6-portrait_750x1334.png: W750 H1334
	iOS\Resources\splash\Default-750@2x~iphone6-landscape_1334x750.png: W1334 H750
	iOS\Resources\splash\Default-1242@3x~iphone6s-portrait_1242x2208.png: W1242 H2208
	iOS\Resources\splash\Default-1242@3x~iphone6s-landscape_2208x1242.png: W2208 H1242


Android:
---------------------------------------
Icons:
	Android\res\\drawable\icon.png: W96 H96
	Android\res\\drawable-ldpi\icon.png: W36 H36
	Android\res\\drawable-mdpi\icon.png: W48 H48
	Android\res\\drawable-hdpi\icon.png: W72 H72
	Android\res\\drawable-xhdpi\icon.png: W96 H96
	Android\res\\drawable-xxhdpi\icon.png: W152 H152
	Android\res\\drawable-xxxhdpi\icon.png: W192 H192

Splashscreens:
	Android\res\\drawable\screen.png: W480 H800
	Android\res\\drawable-land\screen.png: W800 H480
	Android\res\\drawable-ldpi\screen.png: W200 H320
	Android\res\\drawable-land-ldpi\screen.png: W320 H200
	Android\res\\drawable-mdpi\screen.png: W320 H480
	Android\res\\drawable-land-mdpi\screen.png: W480 H320
	Android\res\\drawable-hdpi\screen.png: W480 H800
	Android\res\\drawable-land-hdpi\screen.png: W800 H480
	Android\res\\drawable-xhdpi\screen.png: W720 H1280
	Android\res\\drawable-land-xhdpi\screen.png: W1280 H720
	Android\res\\drawable-xxhdpi\screen.png: W960 H1600
	Android\res\\drawable-land-xxhdpi\screen.png: W1600 H960
	Android\res\\drawable-xxxhdpi\screen.png: W1280 H1920
	Android\res\\drawable-land-xxxhdpi\screen.png: W1920 H1280


Windows Phone:
---------------------------------------
Icons:
	WindowsPhone\Icons\\ApplicationIcon-24x24.png: W24 H24
	WindowsPhone\Icons\\ApplicationIcon-33x33.png: W33 H33
	WindowsPhone\Icons\\ApplicationIcon-44x44.png: W44 H44
	WindowsPhone\Icons\\ApplicationIcon-50x50.png: W50 H50
	WindowsPhone\Icons\\ApplicationIcon-58x58.png: W58 H58
	WindowsPhone\Icons\\ApplicationIcon-58x58.png: W58 H58
	WindowsPhone\Icons\\ApplicationIcon-62x62.png: W62 H62
	WindowsPhone\Icons\\ApplicationIcon-70x70.png: W70 H70
	WindowsPhone\Icons\\ApplicationIcon-71x71.png: W71 H71
	WindowsPhone\Icons\\ApplicationIcon-99x99.png: W99 H99
	WindowsPhone\Icons\\ApplicationIcon-106x106.png: W106 H106
	WindowsPhone\Icons\\ApplicationIcon-120x120.png: W120 H120
	WindowsPhone\Icons\\Background.png: W159 H159
	WindowsPhone\Icons\\ApplicationIcon-150x150.png: W150 H150
	WindowsPhone\Icons\\ApplicationIcon-170x170.png: W170 H170
	WindowsPhone\Icons\\ApplicationIcon-210x210.png: W210 H210
	WindowsPhone\Icons\\ApplicationIcon-360x360.png: W360 H360
	WindowsPhone\Icons\\ApplicationIcon-360x360.png: W360 H360
	WindowsPhone\Icons\\AppTitleIcon-300x300.png: W300 H300
	WindowsPhone\Icons\\AppSquareIcon-358x358.png: W358 H358

Splashscreens:
	WindowsPhone\Splashscreens\\Splashscreen.png: W480 H800


Windows Store:
---------------------------------------
Icons:
	WindowsStore\Icons\\ApplicationIcon-16x16.png: W16 H16
	WindowsStore\Icons\\ApplicationIcon-24x24.png: W24 H24
	WindowsStore\Icons\\ApplicationIcon-30x30.png: W30 H30
	WindowsStore\Icons\\ApplicationIcon-32x32.png: W32 H32
	WindowsStore\Icons\\ApplicationIcon-42x42.png: W42 H42
	WindowsStore\Icons\\ApplicationIcon-48x48.png: W48 H48
	WindowsStore\Icons\\ApplicationIcon-50x50.png: W50 H50
	WindowsStore\Icons\\ApplicationIcon-54x54.png: W54 H54
	WindowsStore\Icons\\ApplicationIcon-70x70.png: W70 H70
	WindowsStore\Icons\\ApplicationIcon-90x90.png: W90 H90
	WindowsStore\Icons\\ApplicationIcon-150x150.png: W150 H150
	WindowsStore\Icons\\ApplicationIcon-120x120.png: W120 H120
	WindowsStore\Icons\\ApplicationIcon-210x210.png: W210 H210
	WindowsStore\Icons\\ApplicationIcon-256x256.png: W256 H256
	WindowsStore\Icons\\ApplicationIcon-270x270.png: W270 H270

Splashscreens:
	WindowsStore\Splashscreens\\Splashscreen-620x300.png: W620 H300
	WindowsStore\Splashscreens\\Splashscreen-868x420.png: W868 H420
	WindowsStore\Splashscreens\\Splashscreen-1116x540.png: W1116 H540


Web:
---------------------------------------
Icons:
	Web\Icons\\favicon.png: W128 H128
	Web\Icons\\favicon.ico.png: W64 H64

Splashscreens:
